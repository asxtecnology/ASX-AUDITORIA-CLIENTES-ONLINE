-- =====================================================
-- ASX Price Monitor — Migration 003: RLS Policies
-- Execute no SQL Editor do Supabase após as migrations 001 e 002
-- =====================================================

-- ─── Habilitar RLS em todas as tabelas ───────────────────────────────────────
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE violations ENABLE ROW LEVEL SECURITY;
ALTER TABLE monitoring_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE price_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE historico_precos ENABLE ROW LEVEL SECURITY;
ALTER TABLE vendedores ENABLE ROW LEVEL SECURITY;
ALTER TABLE alert_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;

-- ─── NOTA: Este sistema usa autenticação própria (JWT via Manus OAuth) ────────
-- As queries ao banco são feitas pelo servidor Node.js com a SERVICE_ROLE key
-- (ou a connection string do pooler com senha), nunca diretamente do browser.
-- Por isso as policies abaixo permitem acesso ao service_role e bloqueiam anon.

-- Helper: verifica se a requisição vem do service role
CREATE OR REPLACE FUNCTION is_service_role()
RETURNS boolean
LANGUAGE sql STABLE
AS $$
  SELECT current_setting('role') = 'service_role'
    OR current_setting('request.jwt.claims', true)::json->>'role' = 'service_role';
$$;

-- ─── users ────────────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "service_role_users" ON users;
CREATE POLICY "service_role_users" ON users
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Bloquear acesso anônimo
DROP POLICY IF EXISTS "deny_anon_users" ON users;
CREATE POLICY "deny_anon_users" ON users
  FOR ALL
  TO anon
  USING (false);

-- ─── products ─────────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "service_role_products" ON products;
CREATE POLICY "service_role_products" ON products
  FOR ALL TO service_role USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "deny_anon_products" ON products;
CREATE POLICY "deny_anon_products" ON products
  FOR ALL TO anon USING (false);

-- ─── clientes ─────────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "service_role_clientes" ON clientes;
CREATE POLICY "service_role_clientes" ON clientes
  FOR ALL TO service_role USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "deny_anon_clientes" ON clientes;
CREATE POLICY "deny_anon_clientes" ON clientes
  FOR ALL TO anon USING (false);

-- ─── violations ───────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "service_role_violations" ON violations;
CREATE POLICY "service_role_violations" ON violations
  FOR ALL TO service_role USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "deny_anon_violations" ON violations;
CREATE POLICY "deny_anon_violations" ON violations
  FOR ALL TO anon USING (false);

-- ─── monitoring_runs ──────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "service_role_monitoring_runs" ON monitoring_runs;
CREATE POLICY "service_role_monitoring_runs" ON monitoring_runs
  FOR ALL TO service_role USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "deny_anon_monitoring_runs" ON monitoring_runs;
CREATE POLICY "deny_anon_monitoring_runs" ON monitoring_runs
  FOR ALL TO anon USING (false);

-- ─── price_snapshots ──────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "service_role_price_snapshots" ON price_snapshots;
CREATE POLICY "service_role_price_snapshots" ON price_snapshots
  FOR ALL TO service_role USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "deny_anon_price_snapshots" ON price_snapshots;
CREATE POLICY "deny_anon_price_snapshots" ON price_snapshots
  FOR ALL TO anon USING (false);

-- ─── historico_precos ─────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "service_role_historico_precos" ON historico_precos;
CREATE POLICY "service_role_historico_precos" ON historico_precos
  FOR ALL TO service_role USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "deny_anon_historico_precos" ON historico_precos;
CREATE POLICY "deny_anon_historico_precos" ON historico_precos
  FOR ALL TO anon USING (false);

-- ─── vendedores ───────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "service_role_vendedores" ON vendedores;
CREATE POLICY "service_role_vendedores" ON vendedores
  FOR ALL TO service_role USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "deny_anon_vendedores" ON vendedores;
CREATE POLICY "deny_anon_vendedores" ON vendedores
  FOR ALL TO anon USING (false);

-- ─── alert_configs ────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "service_role_alert_configs" ON alert_configs;
CREATE POLICY "service_role_alert_configs" ON alert_configs
  FOR ALL TO service_role USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "deny_anon_alert_configs" ON alert_configs;
CREATE POLICY "deny_anon_alert_configs" ON alert_configs
  FOR ALL TO anon USING (false);

-- ─── app_settings ─────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "service_role_app_settings" ON app_settings;
CREATE POLICY "service_role_app_settings" ON app_settings
  FOR ALL TO service_role USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "deny_anon_app_settings" ON app_settings;
CREATE POLICY "deny_anon_app_settings" ON app_settings
  FOR ALL TO anon USING (false);

SELECT 'RLS policies aplicadas com sucesso!' AS resultado;
