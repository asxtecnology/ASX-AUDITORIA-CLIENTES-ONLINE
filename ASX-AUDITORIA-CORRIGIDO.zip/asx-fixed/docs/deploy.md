# Deploy — ASX Price Monitor

## Pré-requisitos
- Node.js 22+
- pnpm 10+
- Projeto Supabase criado (PostgreSQL)

## Variáveis de Ambiente Obrigatórias

| Variável | Descrição |
|----------|-----------|
| `DATABASE_URL` | Connection string PostgreSQL (Supabase Pooler porta 6543) |
| `JWT_SECRET` | Segredo para assinar cookies de sessão (mín. 32 chars) |
| `VITE_APP_ID` | ID da aplicação Manus OAuth |
| `OAUTH_SERVER_URL` | URL do servidor OAuth Manus |

> ⚠️ **Nunca** commite valores reais. Use o painel de variáveis do seu provider de deploy.

## Configurar banco de dados (Supabase)

1. No [Supabase Dashboard](https://supabase.com/dashboard), vá em **SQL Editor**
2. Execute `drizzle/migrations/001_mysql_to_postgresql.sql`
3. Execute `drizzle/migrations/002_seed_revendedores.sql`
4. Execute `supabase/migrations/003_rls_policies.sql`

## Deploy na Vercel

```bash
# Instalar Vercel CLI
npm i -g vercel

# Deploy
vercel --prod
```

Configure as variáveis de ambiente no painel da Vercel em **Settings → Environment Variables**.

## Deploy no Railway

```bash
railway login
railway up
```

Configure as variáveis em **Variables** no painel do Railway.

## CI/CD (GitHub Actions)

Configure os seguintes **Secrets** no repositório GitHub:
`Settings → Secrets and variables → Actions`

- `DATABASE_URL`
- `JWT_SECRET`
- `VITE_APP_ID`
- `OAUTH_SERVER_URL`

## Comandos úteis

```bash
# Verificar envs antes de qualquer coisa
pnpm check:env

# Rodar migrations
pnpm db:push

# Build de produção
pnpm build

# Iniciar em produção
pnpm start
```
