import { describe, it, expect } from "vitest";

describe("Database Configuration", () => {
  it("DATABASE_URL should be set when running in production", () => {
    // Em CI/dev, DATABASE_URL pode ser um placeholder
    const url = process.env.DATABASE_URL;
    if (process.env.NODE_ENV === "production") {
      expect(url).toBeDefined();
      expect(url).toMatch(/^postgresql:\/\/|^postgres:\/\//);
    } else {
      // Em dev/CI, aceitar undefined ou placeholder
      expect(true).toBe(true);
    }
  });

  it("DATABASE_URL should have valid format when set", () => {
    const url = process.env.DATABASE_URL;
    if (url && url !== "postgresql://postgres:placeholder@localhost:5432/postgres") {
      const parsed = new URL(url);
      expect(["postgresql:", "postgres:"]).toContain(parsed.protocol);
      expect(parsed.hostname).toBeTruthy();
    } else {
      expect(true).toBe(true); // placeholder ou não definida em dev
    }
  });
});
