#!/usr/bin/env node
/**
 * check-env.mjs — Valida variáveis de ambiente obrigatórias.
 * Execute com: node scripts/check-env.mjs
 */

const REQUIRED_IN_PRODUCTION = ["DATABASE_URL", "JWT_SECRET", "VITE_APP_ID", "OAUTH_SERVER_URL"];
const OPTIONAL = ["OWNER_OPEN_ID", "BUILT_IN_FORGE_API_URL", "BUILT_IN_FORGE_API_KEY"];

const isProd = process.env.NODE_ENV === "production";
const errors = [];
const warnings = [];

console.log("\n🔍 Verificando variáveis de ambiente...\n");

for (const key of REQUIRED_IN_PRODUCTION) {
  const val = process.env[key];
  if (!val) {
    if (isProd) {
      errors.push(`  ✗ ${key} — OBRIGATÓRIA em produção`);
    } else {
      warnings.push(`  ⚠ ${key} — não definida (ok em dev, obrigatória em produção)`);
    }
  } else {
    console.log(`  ✓ ${key}`);
  }
}

const dbUrl = process.env.DATABASE_URL;
if (dbUrl && !dbUrl.startsWith("postgresql://") && !dbUrl.startsWith("postgres://")) {
  errors.push(`  ✗ DATABASE_URL deve começar com postgresql:// ou postgres://`);
}

if (process.env.JWT_SECRET === "dev-only-insecure-secret-change-me" && isProd) {
  errors.push(`  ✗ JWT_SECRET está com valor padrão inseguro em produção!`);
}

for (const key of OPTIONAL) {
  if (!process.env[key]) warnings.push(`  ⓘ ${key} — opcional, não definida`);
}

if (warnings.length > 0) {
  console.warn("\nAvisos:");
  warnings.forEach((w) => console.warn(w));
}

if (errors.length > 0) {
  console.error("\n❌ ERROS — variáveis obrigatórias ausentes:");
  errors.forEach((e) => console.error(e));
  process.exit(1);
}

console.log("\n✅ Variáveis de ambiente OK\n");
